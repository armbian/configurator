#!/bin/bash

./install.sh
