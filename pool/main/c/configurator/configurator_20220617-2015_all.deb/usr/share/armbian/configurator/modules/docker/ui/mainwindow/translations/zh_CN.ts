<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>ComposeManagerWindow</name>
    <message>
        <location filename="../modulewindow_qt.ui" line="14"/>
        <source>MainWindow</source>
        <translatorcomment>DeepL Translation from Japanese</translatorcomment>
        <translation>主屏幕</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="23"/>
        <source>Installed</source>
        <translatorcomment>DeepL Translation from Japanese</translatorcomment>
        <translation>已安装的服务</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="46"/>
        <source>Available</source>
        <translatorcomment>DeepL Translation from Japanese</translatorcomment>
        <translation>全部服务</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="91"/>
        <source>TextLabel</source>
        <translatorcomment>DeepL Translation from Japanese</translatorcomment>
        <translation>所选服务的名称</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="115"/>
        <source>Up</source>
        <translation>Up</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="140"/>
        <source>Down</source>
        <translation>Down</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="172"/>
        <source>Edit</source>
        <translation>编辑</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="179"/>
        <source>Open folder</source>
        <translation>文件夹</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="214"/>
        <source>Uninstall</source>
        <translatorcomment>Deepl Translation of 削除</translatorcomment>
        <translation>删减</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="245"/>
        <source>Install</source>
        <translation>安装</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="257"/>
        <source>Operations output</source>
        <translation>执行结果</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="280"/>
        <source>Status</source>
        <translation>服务状况</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="294"/>
        <source>YAML</source>
        <translation>docker-compose.yml</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="322"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="331"/>
        <source>Quit</source>
        <translation>结束</translation>
    </message>
</context>
</TS>
