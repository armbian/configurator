## UI

### Generate a translation file

`lupdate modulewindow_qt.ui -ts translations/LOCALE_NAME.ts`

### Edit a translation file

`linguist translations/LOCALE_NAME.ts`

### Update a translation file

TBD