<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ja">
<context>
    <name>ComposeManagerWindow</name>
    <message>
        <location filename="../modulewindow_qt.ui" line="14"/>
        <source>MainWindow</source>
        <translation>本画面</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="23"/>
        <source>Installed</source>
        <translation>インストールのみ</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="46"/>
        <source>Available</source>
        <translation>全サービス</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="91"/>
        <source>TextLabel</source>
        <translation>選択されているサービスの名前</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="115"/>
        <source>Up</source>
        <translation>Up</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="140"/>
        <source>Down</source>
        <translation>Down</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="172"/>
        <source>Edit</source>
        <translation>編集</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="179"/>
        <source>Open folder</source>
        <translation>フォルダ</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="214"/>
        <source>Uninstall</source>
        <translation>削除</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="245"/>
        <source>Install</source>
        <translation>インストール</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="257"/>
        <source>Operations output</source>
        <translation>実行結果</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="280"/>
        <source>Status</source>
        <translation>サービス状態</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="294"/>
        <source>YAML</source>
        <translation>docker-compose.yml</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="322"/>
        <source>File</source>
        <translation>ファイル</translation>
    </message>
    <message>
        <location filename="../modulewindow_qt.ui" line="331"/>
        <source>Quit</source>
        <translation>終了</translation>
    </message>
</context>
</TS>
