./install.sh
